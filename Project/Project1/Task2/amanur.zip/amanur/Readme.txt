Python 3 has been used with numpy and pandas

Task 2.1
- Run the jupyter notebook or the .py file as "python filename"
- For task 2.1 - a - In addition to giving mean times as input, also give max_iteration = 50 (MC=50) to emulate Task 2.1 - Table 1 
- For task 2.1 - b - In addition to giving mean times as input, also give max_iteration = 20 (MC=20) to emulate Task 2.1 - Table 2


The python files have been tested on "VCL -- CSC111 RHEL6 + Anaconda Python reservation"
