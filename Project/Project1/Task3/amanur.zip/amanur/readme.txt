Simulation_task3.py has been tested on VCL : 	CSC111 RHEL6 + Anaconda Python

To run the file : command : python Simulation_task_3.py

Simulation_task_3.py - Stores results batchwise (main file)
super_mean.py - Calculates super mean
Results.pdf - Contains graphs and comments on results



values - contains the mean values for 50 batches per MIAT_NRT
Final_values.csv - The super mean values used to generate graph
